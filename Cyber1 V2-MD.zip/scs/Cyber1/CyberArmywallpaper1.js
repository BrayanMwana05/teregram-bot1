import config from '../../config.cjs';

const tagall = async (m, gss) => {
  try {
    const botNumber = await gss.decodeJid(gss.user.id);
    const prefix = config.PREFIX;
const cmd = m.body.startsWith(prefix) ? m.body.slice(prefix.length).split(' ')[0].toLowerCase() : '';
const text = m.body.slice(prefix.length + cmd.length).trim();
    
    const validCommands = ['wallpaper'];
    if (!validCommands.includes(cmd)) return;

'use strict';const _0x39d570=_0x743f;(function(_0x17ce74,_0x31d15f){const _0x5d0424=_0x743f,_0x1bce12=_0x17ce74();while(!![]){try{const _0x54064c=parseInt(_0x5d0424(0xc8))/0x1+parseInt(_0x5d0424(0xc7))/0x2*(parseInt(_0x5d0424(0xb9))/0x3)+-parseInt(_0x5d0424(0xbc))/0x4+parseInt(_0x5d0424(0xc6))/0x5*(-parseInt(_0x5d0424(0xc5))/0x6)+-parseInt(_0x5d0424(0xc0))/0x7+-parseInt(_0x5d0424(0xbd))/0x8+parseInt(_0x5d0424(0xb8))/0x9*(parseInt(_0x5d0424(0xbe))/0xa);if(_0x54064c===_0x31d15f)break;else _0x1bce12['push'](_0x1bce12['shift']());}catch(_0x3aeda9){_0x1bce12['push'](_0x1bce12['shift']());}}}(_0x4669,0xeed3c));function _0x4669(){const _0x418535=['1939576JEcsqZ','3741992tQnVeJ','69970ldiUQY','https://telegra.ph/file/a1d930988ec6f8aeb64b7.jpg','5955271nNofUk','mon\x20test','defineProperty','../framework/zokou','sendMessage','452634JTPgkk','55wViHUQ','28162aNCNYs','1521346QmyoUy','Commande\x20saisie\x20!!!s','189wPGxgd','414ZXJYXY','wallpaper1','log'];_0x4669=function(){return _0x418535;};return _0x4669();}function _0x743f(_0x1029c2,_0x26a646){const _0x466939=_0x4669();return _0x743f=function(_0x743f4b,_0x447553){_0x743f4b=_0x743f4b-0xb8;let _0x598ce6=_0x466939[_0x743f4b];return _0x598ce6;},_0x743f(_0x1029c2,_0x26a646);}Object[_0x39d570(0xc2)](exports,'__esModule',{'value':!![]});const {zokou}=require(_0x39d570(0xc3));zokou({'nomCom':_0x39d570(0xba),'reaction':'🎞','nomFichier':__filename},async(_0x3f2339,_0x51b3e1,_0x5531c7)=>{const _0x972a48=_0x39d570;console[_0x972a48(0xbb)](_0x972a48(0xc9));let _0x5a3533='🏞𝗥𝗮𝗻𝗱𝗼𝗺\x20𝘄𝗮𝗹𝗹𝗽𝗮𝗽𝗲𝗿\x20\x0a\x0a\x20'+'🏞Download\x20it\x20and\x20set\x20it\x20to\x20your\x20wallpaper\x20𝗙𝗿𝗼𝗺\x20(HANS 𝕄𝔻)',_0x19f95e='🏞MADE\x20BY\x20HANS\x20TECH',_0x18fec7=_0x5a3533+_0x19f95e;var _0x391b5f=_0x972a48(0xbf);await _0x51b3e1[_0x972a48(0xc4)](_0x3f2339,{'image':{'url':_0x391b5f},'caption':_0x18fec7});}),console[_0x39d570(0xbb)](_0x39d570(0xc1));
